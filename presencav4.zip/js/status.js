function make(valor){
    document.getElementById('message').style.backgroundColor=valor;
}