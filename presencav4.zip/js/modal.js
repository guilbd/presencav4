let modal = document.getElementById('notice');
modal.addEventListener('click',closeModal);
function closeModal(){
    modal.style.display="none";
}
